from flask import Flask
import os

def create_app():
    app = Flask(__name__)
    app.config.from_mapping(
        SECRET_KEY=os.environ.get('SECRET_KEY', 'dev-key'),
        FLAG=os.environ.get('FLAG', 'CodeVinciCTF{not_real_flag}')
    )

    from . import routes
    app.register_blueprint(routes.bp)

    return app