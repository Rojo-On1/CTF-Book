from flask import Blueprint, render_template, request, jsonify, current_app
import numpy as np
import json

from .tropical_algebra import TropicalAlgebra

bp = Blueprint('main', __name__)

@bp.route('/')
def index():
    return render_template('index.html')

@bp.route('/api/encrypt', methods=['POST'])
def encrypt():
    data = request.get_json()
    if not data or 'plaintext' not in data:
        return jsonify({'error': 'Missing plaintext'}), 400
    
    try:
        tropical = TropicalAlgebra()
        ciphertext, key = tropical.encrypt(data['plaintext'])
        return jsonify({
            'ciphertext': ciphertext.tolist(),
            'key': key.tolist()
        })
    except Exception as e:
        current_app.logger.error(f"Encryption error: {e}")
        return jsonify({'error': 'Encryption failed'}), 500

@bp.route('/api/decrypt', methods=['POST'])
def decrypt():
    data = request.get_json()
    if not data or 'ciphertext' not in data or 'key' not in data:
        return jsonify({'error': 'Missing ciphertext or key'}), 400
    
    try:
        tropical = TropicalAlgebra()
        ciphertext = np.array(data['ciphertext'])
        key = np.array(data['key'])
        
        if not tropical._is_invertible(key):
            return jsonify({'error': 'Invalid key - matrix not invertible'}), 400
        
        tropical.key = key
        tropical.key_inv = tropical._compute_inverse(key)
        
        plaintext = tropical.decrypt(ciphertext)
        return jsonify({'plaintext': plaintext})
    except Exception as e:
        current_app.logger.error(f"Decryption error: {e}")
        return jsonify({'error': 'Decryption failed'}), 500

@bp.route('/api/challenge', methods=['GET'])
def challenge():
    try:
        flag = current_app.config['FLAG']
        tropical = TropicalAlgebra(size=6) 
        
        if not tropical.key.size or not tropical._is_invertible(tropical.key):
            current_app.logger.error("Generated invalid key matrix")
            raise ValueError("Invalid key matrix generated")
            
        ciphertext, key = tropical.encrypt(flag)
        
        return jsonify({
            'ciphertext': ciphertext.tolist(),
            'key': key.tolist(),
            'hint': 'AHAHAHAHAHAHAHAHAH'
        })
    except Exception as e:
        current_app.logger.error(f"Challenge error: {str(e)}", exc_info=True)
        return jsonify({'error': 'Challenge generation failed', 'details': str(e)}), 500

@bp.route('/health')
def health():
    return jsonify({'status': 'healthy benjamin'})