import numpy as np
from typing import Tuple

class TropicalAlgebra:
    def __init__(self, size: int = 8):
        self.size = size
        self.key = self._generate_invertible_matrix()
        self.key_inv = self._compute_inverse(self.key)

    @staticmethod
    def _generate_invertible_matrix(size: int = 8) -> np.ndarray:
        matrix = np.zeros((size, size))
        np.fill_diagonal(matrix, 50) 
        
        noise = np.random.randint(0, 10, size=(size, size))
        matrix = matrix + noise
        
        if not TropicalAlgebra._is_invertible(matrix):
            np.fill_diagonal(matrix, [100]*size)
        
        return matrix

    @staticmethod
    def _is_invertible(matrix: np.ndarray) -> bool:
        try:
            det = 0
            for i in range(matrix.shape[0]):
                det += matrix[i, i]
            return det != -np.inf
        except:
            return False

    @staticmethod
    def _compute_inverse(matrix: np.ndarray) -> np.ndarray:
        n = matrix.shape[0]
        inv = np.zeros_like(matrix)
        
        for i in range(n):
            for j in range(n):
                if i == j:
                    inv[i,j] = -matrix[i,j]
                else:
                    inv[i,j] = -np.inf
        
        for k in range(n):
            for i in range(n):
                for j in range(n):
                    inv[i,j] = max(inv[i,j], inv[i,k] + inv[k,j])
        
        return inv

    def encrypt(self, plaintext: str) -> Tuple[np.ndarray, np.ndarray]:
        plain_bytes = plaintext.encode('utf-8')
        padding = (-len(plain_bytes)) % self.size
        plain_bytes += bytes([0] * padding)
        
        blocks = np.frombuffer(plain_bytes, dtype=np.uint8)
        blocks = blocks.reshape(-1, self.size)
        
        cipher = []
        for block in blocks:
            cipher_block = self._tropical_matmul(block.reshape(1, -1), self.key)
            cipher.append(cipher_block.flatten())
        
        return np.concatenate(cipher), self.key

    def decrypt(self, ciphertext: np.ndarray) -> str:
        blocks = ciphertext.reshape(-1, self.size)
        
        plain = []
        for block in blocks:
            plain_block = self._tropical_matmul(block.reshape(1, -1), self.key_inv)
            plain.append(plain_block.flatten())
        
        plain_bytes = np.concatenate(plain).astype(np.uint8).tobytes()
        return plain_bytes.decode('utf-8').strip('\x00')

    @staticmethod
    def _tropical_matmul(A: np.ndarray, B: np.ndarray) -> np.ndarray:
        n, m = A.shape[0], B.shape[1]
        p = A.shape[1]
        C = np.full((n, m), -np.inf)
        
        for i in range(n):
            for j in range(m):
                for k in range(p):
                    C[i,j] = max(C[i,j], A[i,k] + B[k,j])
        return C