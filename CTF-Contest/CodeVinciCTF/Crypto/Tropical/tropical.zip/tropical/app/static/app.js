document.addEventListener('DOMContentLoaded', () => {
    const getChallengeBtn = document.getElementById('get-challenge');
    const challengeDisplay = document.getElementById('challenge-display');
    const encryptBtn = document.getElementById('encrypt-btn');
    const plaintextInput = document.getElementById('plaintext');
    const encryptResult = document.getElementById('encrypt-result');
    const decryptBtn = document.getElementById('decrypt-btn');
    const ciphertextInput = document.getElementById('ciphertext-input');
    const keyInput = document.getElementById('key-input');
    const decryptResult = document.getElementById('decrypt-result');
    const submitFlagBtn = document.getElementById('submit-flag');
    const flagInput = document.getElementById('flag-input');
    const resultMessage = document.getElementById('result-message');

    getChallengeBtn.addEventListener('click', getChallenge);
    encryptBtn.addEventListener('click', encryptText);
    decryptBtn.addEventListener('click', decryptText);
    submitFlagBtn.addEventListener('click', submitFlag);

    function createMatrixElement(data, title = '', cols = 8) {
        const container = document.createElement('div');
        container.className = 'matrix-container';
        
        if (title) {
            const titleEl = document.createElement('h3');
            titleEl.className = 'matrix-title';
            titleEl.textContent = title;
            container.appendChild(titleEl);
        }
        
        const grid = document.createElement('div');
        grid.className = 'matrix-grid';
        
        const columnCount = Array.isArray(data[0]) ? data[0].length : cols;
        grid.style.gridTemplateColumns = `repeat(${columnCount}, minmax(40px, 1fr))`;
        
        if (Array.isArray(data[0])) {
            data.forEach(row => {
                row.forEach(val => {
                    grid.appendChild(createMatrixCell(val));
                });
            });
        } else {
            data.forEach(val => {
                grid.appendChild(createMatrixCell(val));
            });
        }
        
        container.appendChild(grid);
        return container;
    }

    function createMatrixCell(value) {
        const cell = document.createElement('div');
        cell.className = 'matrix-cell';
        cell.textContent = value;
        return cell;
    }

    function createTextOutput(content, title = '') {
        const container = document.createElement('div');
        container.className = 'text-output';
        
        if (title) {
            const titleEl = document.createElement('h3');
            titleEl.className = 'output-title';
            titleEl.textContent = title;
            container.appendChild(titleEl);
        }
        
        const contentEl = document.createElement('div');
        contentEl.className = 'output-content';
        contentEl.textContent = content;
        container.appendChild(contentEl);
        
        return container;
    }

    async function getChallenge() {
        try {
            showMessage('Fetching challenge...', 'info');
            const response = await fetch('/api/challenge');
            const data = await response.json();
            
            if (response.ok) {
                challengeDisplay.innerHTML = '';
                challengeDisplay.appendChild(
                    createMatrixElement(data.ciphertext, 'Encrypted Flag')
                );
                challengeDisplay.appendChild(
                    createMatrixElement(data.key, 'Public Key Matrix')
                );
                challengeDisplay.classList.remove('hidden');
                showMessage('Challenge loaded successfully', 'success');
            } else {
                showError(data.error || 'Failed to get challenge');
            }
        } catch (error) {
            showError('Network error: ' + error.message);
        }
    }

    async function encryptText() {
        const text = plaintextInput.value.trim();
        if (!text) {
            showError('Please enter text to encrypt');
            return;
        }

        try {
            showMessage('Encrypting...', 'info');
            const response = await fetch('/api/encrypt', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ plaintext: text })
            });
            
            const data = await response.json();
            
            if (response.ok) {
                encryptResult.innerHTML = '';
                encryptResult.appendChild(
                    createMatrixElement(data.ciphertext, 'Encrypted Result')
                );
                encryptResult.appendChild(
                    createMatrixElement(data.key, 'Encryption Key')
                );
                encryptResult.classList.remove('hidden');
                showMessage('Encryption successful', 'success');
            } else {
                showError(data.error || 'Encryption failed');
            }
        } catch (error) {
            showError('Network error: ' + error.message);
        }
    }

    async function decryptText() {
        let ciphertext, key;
        
        try {
            ciphertext = JSON.parse(ciphertextInput.value.trim());
            key = JSON.parse(keyInput.value.trim());
        } catch (error) {
            showError('Invalid JSON format');
            return;
        }

        try {
            showMessage('Decrypting...', 'info');
            const response = await fetch('/api/decrypt', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ ciphertext, key })
            });
            
            const data = await response.json();
            
            if (response.ok) {
                decryptResult.innerHTML = '';
                decryptResult.appendChild(
                    createMatrixElement(ciphertext, 'Input Ciphertext')
                );
                decryptResult.appendChild(
                    createMatrixElement(key, 'Input Key Matrix')
                );
                decryptResult.appendChild(
                    createTextOutput(data.plaintext, 'Decrypted Plaintext')
                );
                decryptResult.classList.remove('hidden');
                showMessage('Decryption successful', 'success');
            } else {
                showError(data.error || 'Decryption failed');
            }
        } catch (error) {
            showError('Network error: ' + error.message);
        }
    }

    async function submitFlag() {
        const flag = flagInput.value.trim();
        if (!flag) {
            showError('Please enter a flag');
            return;
        }

        // Actually fake submitter but its 6:30 AM and im in after
        if (flag.startsWith('CTF{') && flag.endsWith('}')) {
            showMessage('Flag submitted successfully!', 'success');
        } else {
            showError('Invalid flag format');
        }
    }

    function showMessage(message, type = 'info') {
        resultMessage.textContent = message;
        resultMessage.className = type;
        
        if (type === 'info') {
            setTimeout(() => {
                if (resultMessage.textContent === message) {
                    resultMessage.className = 'hidden';
                }
            }, 3000);
        }
    }

    function showError(message) {
        showMessage(message, 'error');
    }

    encryptResult.classList.add('hidden');
    decryptResult.classList.add('hidden');
    challengeDisplay.classList.add('hidden');
});